package com.jpmorgan.assignment.marsroverspringboot.domain;

public enum Command {

    L("Left"),
    R("Right"),
    F("Forward"),
	B("Backward");

    private String commandExplain;

    Command(String commandExplain) {
        this.commandExplain = commandExplain;
    }

    public String commandExplain() {
        return commandExplain;
    }

}
