package com.jpmorgan.assignment.marsroverspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

import com.jpmorgan.assignment.marsroverspringboot.config.ApplicationConfiguration;
import com.jpmorgan.assignment.marsroverspringboot.config.RestConfiguration;

@SpringBootApplication
@Import({ ApplicationConfiguration.class, RestConfiguration.class })
public class MarsRoverSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(MarsRoverSpringbootApplication.class, args);
	}
}
