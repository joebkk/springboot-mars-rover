package com.jpmorgan.assignment.marsroverspringboot.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.jpmorgan.assignment.marsroverspringboot.domain.Command;
import com.jpmorgan.assignment.marsroverspringboot.domain.Coordinate;
import com.jpmorgan.assignment.marsroverspringboot.domain.Movement;
import com.jpmorgan.assignment.marsroverspringboot.domain.Position;
import com.jpmorgan.assignment.marsroverspringboot.domain.Rover;
import com.jpmorgan.assignment.marsroverspringboot.message.MessageService;
import com.jpmorgan.assignment.marsroverspringboot.repo.RoverRepo;

@Service
public class RoverServiceImpl implements RoverService {

    private PositionService positionService;
    private MessageService messageService;
    private RoverRepo roverRepo;
    
    @Autowired
	public RoverServiceImpl(PositionService positionService, MessageService messageService, RoverRepo roverRepo) {
		this.positionService = positionService;
		this.messageService = messageService;
		this.roverRepo = roverRepo;
	}
    
    @Override
    public Movement create(Rover rover) {
    	if (rover == null) {
            throw new IllegalArgumentException(
            		messageService.getMessage("message.general.object.notNull", new Object[]{Rover.class}));
        }
    	
    	String name = rover.getName();
    	int x = rover.getPosition().getCoordinate().getX();
    	int y = rover.getPosition().getCoordinate().getY();
    	String orientation = rover.getPosition().getDirection().toString();
    	
    	Movement movement = roverRepo.save(new Movement(name, x, y, orientation));
        
    	return movement;
    }
    
    @Override
    public Movement getCurrentPosition(Rover rover) { 
    	if (rover == null) {
            throw new IllegalArgumentException(
            		messageService.getMessage("message.general.object.notNull", new Object[]{Rover.class}));
        }
    	
        List<Movement> movements = roverRepo.findByRoverName(rover.getName());
        movements.sort((Movement s1, Movement s2)->s2.getMovementId().compareTo(s1.getMovementId())); 
        
		return movements.get(0);
    }
    
    @Override
    public Position explore(Rover rover) {
        if (rover == null) {
            throw new IllegalArgumentException(
            		messageService.getMessage("message.general.object.notNull", new Object[]{Rover.class}));
        }

        Position position = rover.getPosition();
        Coordinate plateau = rover.getPlateau();        

        if (!CollectionUtils.isEmpty(rover.getCommands())) {
            for (Command command : rover.getCommands()) {
            	
                if (!position.checkMobility(position, plateau)) {
                    position.setIsImmobile(true);
                    return position;
                }
                
                position = positionService.changePosition(position, command);
                
                int x = position.getCoordinate().getX();
                int y = position.getCoordinate().getY();
                String orientation = position.getDirection().toString();
                roverRepo.save(new Movement(rover.getName(), x, y, orientation));
            }
        }

        return position;
    }
    
    @Override
    public List<Position> explores(List<Rover> rovers) {
        if (CollectionUtils.isEmpty(rovers)) {
            throw new IllegalArgumentException(
            		messageService.getMessage("message.rovers.notNullorEmpty", null));
        }

        List<Position> positions = new ArrayList<>();

        if (!CollectionUtils.isEmpty(rovers)) {
            for (Rover rover : rovers) {
                positions.add(explore(rover));
            }
        }

        return positions;
    }

}
