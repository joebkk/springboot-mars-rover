package com.jpmorgan.assignment.marsroverspringboot.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Movement {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long movementId;
    private String roverName;
    private int x;
    private int y;
    private String orientation;
    
    public Movement() {
    	
	}
    
	public Movement(String roverName, int x, int y, String orientation) {
		super();
		this.roverName = roverName;
		this.x = x;
		this.y = y;
		this.orientation = orientation;
	}

	public Long getMovementId() {
		return movementId;
	}
	
	public void setMovementId(Long movementId) {
		this.movementId = movementId;
	}
	
	public String getRoverName() {
		return roverName;
	}
	
	public void setRoverName(String roverName) {
		this.roverName = roverName;
	}
	
	public int getX() {
		return x;
	}
	
	public void setX(int x) {
		this.x = x;
	}
	
	public int getY() {
		return y;
	}
	
	public void setY(int y) {
		this.y = y;
	}
	
	public String getOrientation() {
		return orientation;
	}
	
	public void setOrientation(String orientation) {
		this.orientation = orientation;
	}
}
