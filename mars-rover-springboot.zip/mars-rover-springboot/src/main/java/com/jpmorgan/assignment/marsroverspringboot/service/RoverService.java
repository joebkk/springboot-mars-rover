package com.jpmorgan.assignment.marsroverspringboot.service;

import java.util.List;

import com.jpmorgan.assignment.marsroverspringboot.domain.Movement;
import com.jpmorgan.assignment.marsroverspringboot.domain.Position;
import com.jpmorgan.assignment.marsroverspringboot.domain.Rover;

public interface RoverService {
	
	public Movement create(Rover rover);
	public Movement getCurrentPosition(Rover rover);
    public Position explore(Rover rover);
    public List<Position> explores(List<Rover> rovers);
}
