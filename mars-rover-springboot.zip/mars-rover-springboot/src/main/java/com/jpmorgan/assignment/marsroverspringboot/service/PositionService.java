package com.jpmorgan.assignment.marsroverspringboot.service;

import com.jpmorgan.assignment.marsroverspringboot.domain.Command;
import com.jpmorgan.assignment.marsroverspringboot.domain.Position;

public interface PositionService {

    public Position changePosition(Position position, Command command);

}
