package com.jpmorgan.assignment.marsroverspringboot.domain.builder;

import com.jpmorgan.assignment.marsroverspringboot.domain.Coordinate;
import com.jpmorgan.assignment.marsroverspringboot.domain.Direction;
import com.jpmorgan.assignment.marsroverspringboot.domain.Position;

public class PositionBuilder {

    private Coordinate coordinate;
    private Direction direction;
    private boolean isImmobile = false;

    public Position doBuild() {
        Position position = new Position();
        position.setCoordinate(coordinate);
        position.setDirection(direction);
        position.setIsImmobile(isImmobile);
        return position;
    }

    public PositionBuilder coordinate(Coordinate coordinate) {
        this.coordinate = coordinate;
        return this;
    }

    public  PositionBuilder direction(Direction direction) {
        this.direction = direction;
        return this;
    }

    public PositionBuilder isImmobile(boolean isImmobile) {
        this.isImmobile = isImmobile;
        return this;
    }
}
