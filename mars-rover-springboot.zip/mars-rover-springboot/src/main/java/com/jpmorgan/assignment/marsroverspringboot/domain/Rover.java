package com.jpmorgan.assignment.marsroverspringboot.domain;

import java.util.List;
import java.util.Objects;

public class Rover {
	private String name;
    private Coordinate plateau;
    private Position position;
    private List<Command> commands;

    public Rover() {

    }

	public Rover(Coordinate plateau, Position position, List<Command> commands) {
        this.plateau = plateau;
        this.position = position;
        this.commands = commands;
    }
		
    public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Coordinate getPlateau() {
        return plateau;
    }

    public void setPlateau(Coordinate plateau) {
        this.plateau = plateau;
    }

    public Position getPosition() {
        return this.position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    public List<Command> getCommands() {
        return this.commands;
    }

    public void setCommands(List<Command> commands) {
        this.commands = commands;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Rover rover = (Rover) o;

        if (!Objects.equals(position, rover.position)) return false;
        return Objects.equals(commands, rover.commands);
    }

    @Override
    public int hashCode() {
        int result = position != null ? position.hashCode() : 0;
        result = 31 * result + (commands != null ? commands.hashCode() : 0);
        return result;
    }

}
