package com.jpmorgan.assignment.marsroverspringboot.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.jpmorgan.assignment.marsroverspringboot.domain.Movement;

@Repository
public interface RoverRepo extends JpaRepository<Movement, Integer> {
	List<Movement> findByRoverName(String name);

}
