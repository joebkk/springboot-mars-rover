package com.jpmorgan.assignment.marsroverspringboot.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jpmorgan.assignment.marsroverspringboot.domain.Movement;
import com.jpmorgan.assignment.marsroverspringboot.domain.Position;
import com.jpmorgan.assignment.marsroverspringboot.domain.Rover;
import com.jpmorgan.assignment.marsroverspringboot.service.RoverService;

@RequestMapping("/api/mars-rover")
@RestController
public class MoveController {

    private RoverService roverService;
    
    @Autowired
   	public MoveController(RoverService roverService) {
   		this.roverService = roverService;
   	}
    
    @PostMapping(value = "/create")
    ResponseEntity<String> create(@RequestBody Rover rover) {
    	Movement movement = roverService.create(rover);
        
        String output = "New Rover: " + rover.getName() + ", " +
        		"{Coordiate:" + movement.getX() + "," + movement.getY() + " ; " +
        		"Direction: " + movement.getOrientation() + "}";
    	
        return new ResponseEntity<>(output, HttpStatus.OK);
    }
    
    @PostMapping(value = "/current")
    ResponseEntity<String> currentPosition(@RequestBody Rover rover) {
    	Movement movement = roverService.getCurrentPosition(rover);
    	
    	String output = "Rover: " + movement.getRoverName() + ", " +
        		"Current Position: {Coordiate:" + movement.getX() + "," + movement.getY() + " ; " +
    			"Direction: " + movement.getOrientation() + "}";
    	
        return new ResponseEntity<>(output, HttpStatus.OK);
    }

    @PostMapping(value = "/move")
    ResponseEntity<Position> explore(@RequestBody Rover rover) {
        Position output = roverService.explore(rover);
        return new ResponseEntity<>(output, HttpStatus.OK);
    }

    @PostMapping(value = "/moves")
    ResponseEntity<List<Position>> explores(@RequestBody List<Rover> rovers) {
        List<Position> output = roverService.explores(rovers);
        return new ResponseEntity<>(output, HttpStatus.OK);
    }
}
