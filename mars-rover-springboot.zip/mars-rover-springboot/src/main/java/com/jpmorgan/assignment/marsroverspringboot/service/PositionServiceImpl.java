package com.jpmorgan.assignment.marsroverspringboot.service;

import org.springframework.stereotype.Service;

import com.jpmorgan.assignment.marsroverspringboot.domain.Command;
import com.jpmorgan.assignment.marsroverspringboot.domain.Coordinate;
import com.jpmorgan.assignment.marsroverspringboot.domain.Direction;
import com.jpmorgan.assignment.marsroverspringboot.domain.Position;

@Service
public class PositionServiceImpl implements PositionService {
	
	@Override
    public Position changePosition(Position position, Command command) {
        Direction direction = position.getDirection();
        Coordinate coordinate = position.getCoordinate();

        switch (command) {
            case L:
                direction = direction.turnLeft();
                break;
            case R:
                direction = direction.turnRight();
                break;
            case F:
                coordinate = coordinate.moveForward(direction.moveX(), direction.moveY());
                break;
            case B:
                coordinate = coordinate.moveBackward(direction.moveX(), direction.moveY());
                break;
        }

        return new Position(coordinate, direction);
    }

}
