package com.jpmorgan.assignment.marsroverspringboot.domain.builder;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.jpmorgan.assignment.marsroverspringboot.domain.Compass;
import com.jpmorgan.assignment.marsroverspringboot.domain.Coordinate;
import com.jpmorgan.assignment.marsroverspringboot.domain.Direction;
import com.jpmorgan.assignment.marsroverspringboot.domain.Position;

@SpringBootTest(classes = PositionBuilder.class)
public class PositionBuilderTest {

    @Test
    public void shouldPositionBuilder() {
        Coordinate coordinate = new CoordinateBuilder().x(5).y(5).doBuild();
        Direction direction = new Compass.North();
        boolean isImmobile = false;

        Position position = new PositionBuilder().coordinate(coordinate).direction(direction).isImmobile(isImmobile).doBuild();

        Assertions.assertAll("PositionBuilder fail",
                () -> Assertions.assertEquals(position.getCoordinate().getX(), coordinate.getX()),
                () -> Assertions.assertEquals(position.getCoordinate().getY(), coordinate.getY()),
                () -> Assertions.assertEquals(position.getDirection(), direction),
                () -> Assertions.assertEquals(position.isImmobile(), isImmobile));

    }

}