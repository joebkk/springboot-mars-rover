package com.jpmorgan.assignment.marsroverspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarsRoverSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
