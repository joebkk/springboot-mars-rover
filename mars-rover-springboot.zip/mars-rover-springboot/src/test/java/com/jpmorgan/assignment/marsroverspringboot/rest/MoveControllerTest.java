package com.jpmorgan.assignment.marsroverspringboot.rest;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.jpmorgan.assignment.marsroverspringboot.MarsRoverSpringbootApplication;
import com.jpmorgan.assignment.marsroverspringboot.domain.Position;
import com.jpmorgan.assignment.marsroverspringboot.domain.Rover;
import com.jpmorgan.assignment.marsroverspringboot.service.RoverService;

@SpringBootTest(classes = MarsRoverSpringbootApplication.class)
public class MoveControllerTest {

    @InjectMocks
    private MoveController moveController;

    @Mock
    private RoverService roverService;

    @Test
    public void shouldExplore() {
        Mockito.when(roverService.explore(Mockito.any(Rover.class))).thenReturn(new Position());

        moveController.explore(new Rover());
    }

    @Test
    public void shouldExplores() {
        List<Rover> input = new ArrayList<>();
        List<Position> result = new ArrayList<>();
        Mockito.when(roverService.explores(input)).thenReturn(result);

        moveController.explores(input);
    }


}