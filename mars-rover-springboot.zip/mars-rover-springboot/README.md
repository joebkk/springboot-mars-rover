## Mars Rover Spring Boot Application
This is a simple demo application for robotic rovers landed on Mars. 

It uses spring boot and H2 in memory database with REST style architecture.

### Input:
The input is in json format. Its first line is name of rover. This must be unique in order to identity the right rover when landed.

For move request, input can also include a series of instructions telling the rover how to explore the plateau, as well as the upper-right coordinates of the plateau.

In this application, the lower-left coordinates are assumed to be 0,0.

The rest of the input is information pertaining to the rovers that have been deployed. 

### Output:

The output for each rover is its final co-ordinates and heading.


### Test Input:
```
5 5
1 2 N
LMLMLMLMM
3 3 E
MMRMMRMRRM
```
### Expected Output:
```
1 3 N
5 1 E
```

## Running API
```
1. To create rover:
	send post request to http://localhost:8080/api/mars-rover/create with create_request.json	
	
2. To move a single rover:
	send post request to http://localhost:8080/api/mars-rover/move with either move_request1.json or move_request2.json
	
3. To move multiple rovers:
	send post request to http://localhost:8080/api/mars-rover/moves with multiple_rover_move_request.json
	
4. To check current position:
	send post request to http://localhost:8080/api/mars-rover/current with check_current_position.json
```




